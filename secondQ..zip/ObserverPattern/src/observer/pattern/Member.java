
package observer.pattern;

public class Member implements Observer{
    private String memberName;
    private Subject subject;

    public String getmemberName() {
        return memberName;
    }

    public void setmemberName(String memberName) {
        this.memberName = memberName;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }
    
    @Override
    public void update(String announcementDesc) {
        System.out.println("Hello " + memberName + ", " + announcementDesc + " is scheduled for this week.");
    }
    
}
