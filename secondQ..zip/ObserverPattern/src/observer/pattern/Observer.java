
package observer.pattern;


public interface Observer {
    public void update(String announcementDesc);
    
}
