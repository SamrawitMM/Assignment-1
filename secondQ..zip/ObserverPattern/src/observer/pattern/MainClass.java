
package observer.pattern;

public class MainClass {
    public static void main(String[] args){
       Member member1 = new Member();
       member1.setmemberName("Bezuayehu Tegegne");
       Member member2 = new Member();
       member2.setmemberName("Etagegnehugn Mekonen");
       Member member3 = new Member();
       member3.setmemberName("Engudaye Tesfaye");
       
       Announcement business = new Announcement();
       business.setStatementName("Meeting at 4:00 comming week Thurday on the agenda <<Business Issues>> ");
       business.setReady(false);
       
       business.registerObserver(member1);
       business.registerObserver(member2);
       business.registerObserver(member3);

       
       // After one week
        business.setReady(true);
        
        //member 3 wants to unregister from getting scheduler announcer
        
        business.removeObserver(member3);
        business.setReady(true);

    }
}
