
package observer.pattern;

public class ObserverPattern {

    public static void main(String[] args) {
       
    }
    
}
