
package observer.pattern;

import java.util.ArrayList;
import java.util.List;

public class Announcement implements Subject{
    private static String statementName;
    private boolean ready;
    private List<Observer> listOfObservers = new ArrayList<Observer>();

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean ready) {
        this.ready = ready;
        if(ready == true){
            notifyObservers();
        }
    }
    
    public String getStatementName() {
        return statementName;
    }

    public void setStatementName(String statementName) {
        this.statementName = statementName;
    }

    public List<Observer> getListOfObservers() {
        return listOfObservers;
    }

    public void setListOfObservers(List<Observer> listOfObservers) {
        this.listOfObservers = listOfObservers;
    }

    
    @Override
    public void registerObserver(Observer observer) {
        listOfObservers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        listOfObservers.remove(observer);

    }

    @Override
    public void notifyObservers() {
        System.out.println("Notifying all registered members, when a new meeting is scheduled.");
        for(Observer observer : listOfObservers){
            observer.update(statementName);
        }
        
    }
    
}
