
package singletonpattern;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class SingletonPattern {

    public static void main(String[] args) {
        // Single Object across the application life cycle, so the scope is at application level.
        Singleton instance = Singleton.getInstance();
        // Uses the already created instance
        Singleton instance1 = Singleton.getInstance();
        // Uses the already created instance
        Singleton instance2 = Singleton.getInstance();
        // Uses the already created instance
        Singleton instance3 = Singleton.getInstance();
        
        Connection conn = Singleton.getInstance().getDBConnection();
        try{
            String query = "Select * from student";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("Student Database");
            while(resultSet.next()){
            System.out.println(resultSet.getString(1)+" "+resultSet.getString(2));
            }
        }catch(Exception e){
        System.out.println("Got some error during connection.");
        }
        

    }
    
}
