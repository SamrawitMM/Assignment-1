
package singletonpattern;
import java.sql.Connection;
import java.sql.DriverManager;


public final class Singleton {
    private static int counter = 0;
    private static Singleton instance = new Singleton();
    public static Singleton getInstance() { return instance; }
    private Singleton() { 
        counter++;
        System.out.println("Counter Value " + counter);
    }  
    static Connection conn = null;
    public static Connection getDBConnection(){
    try{ 
        if(conn == null){
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "");
        }
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return conn;
    
    
}
}